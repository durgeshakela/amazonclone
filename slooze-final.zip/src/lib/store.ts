export const getRole = () => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("role");
  }
  return null;
};

export const setRole = (role: string) => {
  localStorage.setItem("role", role);
};
