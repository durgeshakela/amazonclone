'use client';
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { getRole } from "@/lib/store";

export default function Dashboard() {
  const router = useRouter();

  useEffect(() => {
    const role = getRole();
    if (role !== "manager") {
      router.push("/products");
    }
  }, []);

  return <div className="p-10">Manager Dashboard</div>;
}
