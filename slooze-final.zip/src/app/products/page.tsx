'use client';
import { useState, useEffect } from "react";
import { getRole } from "@/lib/store";
import Link from "next/link";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [role, setRole] = useState("");

  useEffect(() => {
    setRole(getRole());
  }, []);

  const addProduct = () => {
    const newProduct = { id: Date.now(), name, price };
    setProducts([...products, newProduct]);
    setName("");
    setPrice("");
  };

  const deleteProduct = (id) => {
    setProducts(products.filter((p) => p.id !== id));
  };

  return (
    <div className="p-10">
      <h1>Products</h1>

      {role === "manager" && (
        <Link href="/dashboard">Go to Dashboard</Link>
      )}

      <br/><br/>

      <input placeholder="Name" value={name} onChange={(e)=>setName(e.target.value)} />
      <input placeholder="Price" value={price} onChange={(e)=>setPrice(e.target.value)} />
      <button onClick={addProduct}>Add</button>

      <ul>
        {products.map((p) => (
          <li key={p.id}>
            {p.name} - ₹{p.price}
            <button onClick={()=>deleteProduct(p.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
