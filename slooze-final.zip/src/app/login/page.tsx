'use client';
import { useRouter } from "next/navigation";
import { setRole } from "@/lib/store";
import { useState } from "react";

export default function Login() {
  const [role, setRoleState] = useState("manager");
  const router = useRouter();

  const handleLogin = () => {
    setRole(role);
    router.push("/products");
  };

  return (
    <div className="p-10">
      <h1>Login</h1>
      <select onChange={(e) => setRoleState(e.target.value)}>
        <option value="manager">Manager</option>
        <option value="store">Store Keeper</option>
      </select>
      <br/><br/>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}
